/**************************************************
 * Common Global Attribute
 **************************************************/
#ifndef Conventions_str
#define Conventions_str "CF-1.5"
#endif

#ifndef Metadata_Conventions_str
#define Metadata_Conventions_str "CF-1.5, Unidata Dataset Discovery v1.0"
#endif

#ifndef standard_name_vocabulary_str
#define standard_name_vocabulary_str "CF Standard Name Table (version 17, 24 March 2011)"
#endif

#ifndef project_common_str
#define project_common_str "NESDIS STAR"  
#endif

#ifndef project_nccf_str
#define project_nccf_str "NESDIS Common Cloud Framework" //NCCF products:  MetopB/C,GPM
#endif

#ifndef project_nde_str
#define project_nde_str "NPP Data Exploitation" //NDE products: NPP,N20,N21
#endif

#ifndef title_snd_str
#define title_snd_str "NPR_MIRS_SND"
#endif

#ifndef title_img_str
#define title_img_str "NPR_MIRS_IMG"
#endif

#ifndef summary_snd_str
#define summary_snd_str "MIRS sounding products including temperature, water vapor, and hydrometeor profiles."
#endif

#ifndef summary_img_str
#define summary_img_str "MIRS imaging products including surface emissivity, TPW, CLW, RWP, IWP, LST."
#endif

#ifndef institution_str
#define institution_str "DOC/NOAA/NESDIS/OSPO > Office of Satellite and Product Operations, NESDIS, NOAA, U.S. Department of Commerce"
#endif

#ifndef naming_authority_common_str
#define naming_authority_common_str "gov.noaa.nesdis.star" 
#endif

#ifndef naming_authority_nde_str
#define naming_authority_nde_str "gov.noaa.nesdis.ncei" //NDE projects: NPP,N20,N21
#endif

#ifndef naming_authority_nccf_str
#define naming_authority_nccf_str "gov.noaa.nesdis.ospo" //NCCF projects: MetopB/C,GPM
#endif

#ifndef NPP_platform_str
#define NPP_platform_str "NPP"
#endif

#ifndef NPP_instrument_str
#define NPP_instrument_str "ATMS"
#endif

#ifndef N20_platform_str
#define N20_platform_str "N20"
#endif

#ifndef N20_instrument_str
#define N20_instrument_str "ATMS"
#endif

#ifndef N21_platform_str
#define N21_platform_str "N21"
#endif

#ifndef N21_instrument_str
#define N21_instrument_str "ATMS"
#endif

#ifndef metopSGA1_platform_str
#define metopSGA1_platform_str "metopSGA1"
#endif

#ifndef metopSGA1_instrument_str
#define metopSGA1_instrument_str "MWS"
#endif

#ifndef METOPA_platform_str
#define METOPA_platform_str "Metop-A"
#endif

#ifndef METOPA_instrument_str
#define METOPA_instrument_str "AMSU-A,MHS"
#endif

#ifndef METOPB_platform_str
#define METOPB_platform_str "Metop-B"
#endif

#ifndef METOPB_instrument_str
#define METOPB_instrument_str "AMSU-A,MHS"
#endif

#ifndef METOPC_platform_str
#define METOPC_platform_str "Metop-C"
#endif

#ifndef METOPC_instrument_str
#define METOPC_instrument_str "AMSU-A,MHS"
#endif

#ifndef GPM_platform_str
#define GPM_platform_str "GPM"
#endif

#ifndef GPM_instrument_str
#define GPM_instrument_str "GMI"
#endif

#ifndef creator_name_str
#define creator_name_str "DOC/NOAA/NESDIS/STAR > MIRS TEAM, Center for Satellite Applications and Research, NESDIS, NOAA, U.S. Department of Commerce"
#endif

#ifndef creator_email_str
#define creator_email_str "Christopher.Grassotti@noaa.gov, Quanhua.Liu@noaa.gov, Shu-yan.Liu@noaa.gov, Yong-Keun.Lee@noaa.gov, YanZhou@umd.edu "
#endif

#ifndef creator_url_str
#define creator_url_str "http://www.star.nesdis.noaa.gov/mirs"
#endif

#ifndef publisher_name_common_str
#define publisher_name_common_str "DOC/NOAA/NESDIS/STAR > Center for Satellite Applications and Research, NESDIS, NOAA, U.S. Department of Commerce."
#endif

#ifndef publisher_name_nccf_str
#define publisher_name_nccf_str "DOC/NOAA/NESDIS/OSPO > Office of Satellite and Product Operations, NESDIS, NOAA, U.S. Department of Commerce." // NCCF products: MetopB/C,GPM
#endif

#ifndef publisher_name_nde_str
#define publisher_name_nde_str "DOC/NOAA/NESDIS/NDE > NPP Data Exploitation, NESDIS, NOAA, U.S. Department of Commerce" //NDE products: NPP,N20,N21
#endif

#ifndef publisher_email_str
#define publisher_email_str "espcoperations@noaa.gov"
#endif

#ifndef publisher_url_str
#define publisher_url_str "http://www.ospo.noaa.gov/"
#endif

#ifndef references_str
#define references_str "http://www.star.nesdis.noaa.gov/mirs/documentation.php"
#endif

#ifndef processing_level_str
#define processing_level_str "NOAA Level 2 data"
#endif

#ifndef cdm_data_type_str
#define cdm_data_type_str "Swath"
#endif

#ifndef geospatial_lat_units_str
#define geospatial_lat_units_str "degrees_north"
#endif

#ifndef geospatial_lon_units_str
#define geospatial_lon_units_str "degrees_east"
#endif

#ifndef keyword_common_str
#define keyword_common_str "MiRS, passive microwave retrieval"
#endif

#ifndef keyword_atms_str
#define keyword_atms_str "MiRS, ATMS, passive microwave retrieval"
#endif

#ifndef keyword_amsua_str
#define keyword_amsua_str "MiRS, AMSUA/MHS, passive microwave retrieval"
#endif

#ifndef keyword_gmi_str
#define keyword_gmi_str "MiRS, GMI, passive microwave retrieval"
#endif

#ifndef keyword_ssmis_str
#define keyword_ssmis_str "MiRS, SSMIS, passive microwave retrieval"
#endif
